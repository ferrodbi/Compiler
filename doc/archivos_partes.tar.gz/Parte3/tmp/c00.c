// Ejemplo sencillo del uso de operadores aritmeticos.
// Debe devolver el mismo numero que se le proporciona.
{ int a;

  read(a);
  a = (((a + a) * 2) / 2 ) - a ;
  print(a);
}
