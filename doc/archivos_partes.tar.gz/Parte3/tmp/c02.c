// Ejemplo de uso de operadores de incremento.
// Debe devolver: 5, 5, 4, 5, 3, 3, 4, 3
{ int x; int y; int z;

  x = 4; print(++x); print(x);
  x = 4; print(x++); print(x);
  x = 4; print(--x); print(x);
  x = 4; print(x--); print(x);
} 
