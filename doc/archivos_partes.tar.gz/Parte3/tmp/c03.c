// Ejemplo sencillo de manipulacion de vectores.
// Devuelve la cuenta inversa desde 9
{ int a[10]; 
  int i;

  for (i = 0; i < 10; i++) a[i] = i;
  for (i = 9; i >= 0; i--) print(a[i]);
}
