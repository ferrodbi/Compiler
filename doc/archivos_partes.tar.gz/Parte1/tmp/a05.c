// Ejemplo de uso de asignacion y operadores de incremento
{ int a; int b;

  a=4;  print(a++); print(a);
  a=4;  print(++a); print(a);
  a=4;  b=a++; print (b); print (a);
} 
