// Errores lexicos sin sentido: 1 error
{
  int  aAa123_2016;
  int c#;                         // caracter desconocido

  c = ((aAa123_2016 + 3.56) * .34 ) / 2.;
}
