// Ejemplo sencillo del uso de operadores aritmeticos
{ int a;

  read(a);
  a = (((a + a) * 2) / 2 ) - a ;
  print(a);
}
